import Class.Student;

public class App {
    public static void main(String[] args) throws Exception {
        Student studentOne = new Student("Gabriel Silva", 20, 1, "ADS");

        studentOne.showData();
    }
}
