package Main;

public class Carro extends Veiculo{
    public Carro(String modelo, String marca, int ano, double valor, int quantidadeDePortas) {
        super(modelo, marca, ano, valor);
        this.quantidadeDePortas = quantidadeDePortas;
    }

    private int quantidadeDePortas;

    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public int getAno() {
        return ano;
    }
    public void setAno(int ano) {
        this.ano = ano;
    }
    public int getQuantidadeDePortas() {
        return quantidadeDePortas;
    }
    public void setQuantidadeDePortas(int quantidadeDePortas) {
        this.quantidadeDePortas = quantidadeDePortas;
    }
    public double getValor() {
        return valor;
    }
    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public void imprimirInformacoes() {
        System.out.println("O modelo " + this.modelo + ", ano " + this.ano + ", da marca "  +  this.marca + ", do valor R$" + this.valor +  " e tem " + this.quantidadeDePortas + " portas");
    }
}
